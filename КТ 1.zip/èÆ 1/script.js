(function(){

let achevmentNum = document.querySelectorAll('.achevmentNum');
let limit = 0;
window.addEventListener('scroll', function(){  
  if( limit == achevmentNum.length ){ return; }
  
  for(let i = 0; i < achevmentNum.length; i++){
    let pos = achevmentNum[i].getBoundingClientRect().top;
    let win = window.innerHeight - 40;
    if( pos < win && achevmentNum[i].dataset.stop === "0" ){
      achevmentNum[i].dataset.stop = 1;
      let x = 0;
      limit++;
      let int = setInterval(function(){
        x = x + Math.ceil( achevmentNum[i].dataset.to / 50 ); 
        achevmentNum[i].innerText = x;
        if( x > achevmentNum[i].dataset.to ){
          achevmentNum[i].innerText = achevmentNum[i].dataset.to;
          clearInterval(int);
        }
      }, 60);
    }
  }
});

})();

