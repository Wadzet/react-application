var typed = new Typed(".f-page-typed-text",{
    strings: [,  "Designer", "Developer", "Freelancer", "Photographer"] ,
    typeSpeed: 100,
    backSpeed: 50,
    backDelay: 2000,
    loop: true    
    })